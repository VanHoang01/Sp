﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcMovie.Migrations
{
    public class _DateStamp___Initial
    {
    }
}