﻿using System;

namespace ASC.Tests
{
    public class Class1
    {
    }
}
